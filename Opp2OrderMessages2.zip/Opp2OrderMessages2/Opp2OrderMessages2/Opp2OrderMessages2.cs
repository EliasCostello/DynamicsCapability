﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using Microsoft.Xrm.Sdk.Messages;

using Microsoft.Crm.Sdk.Messages;

namespace Opp2OrderMessages2_EMC
{
    public class Opp2OrderMessages2_EMC : CodeActivity
    {

        //input parameters
        [RequiredArgument]
        [Input("Opportunity")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> opportunityInput { get; set; }

        [Output("Created Order")]
        [ReferenceTarget("salesorder")]
        public OutArgument<EntityReference> salesorderOutput { get; set; }

      


        protected override void Execute(CodeActivityContext context)
        {

            ITracingService tracingService = context.GetExtension<ITracingService>();

            tracingService.Trace("Begin:");

            IWorkflowContext iWorkflowContext = context.GetExtension<IWorkflowContext>();

            IOrganizationServiceFactory factory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = factory.CreateOrganizationService(iWorkflowContext.InitiatingUserId);
            tracingService.Trace("Starting Opportunity References:");
            EntityReference opportunityRef = opportunityInput.Get(context);

            
            GenerateSalesOrderFromOpportunityRequest req = new GenerateSalesOrderFromOpportunityRequest();
            req.OpportunityId = opportunityRef.Id;
            req.ColumnSet = new ColumnSet(true);
            GenerateSalesOrderFromOpportunityResponse resp = (GenerateSalesOrderFromOpportunityResponse)service.Execute(req);
            salesorderOutput.Set(context, new EntityReference("salesorder", resp.Entity.Id));
            //use returned quote

            tracingService.Trace("Complete:");
        }

       
    }
}