﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;

namespace ConvertOpptoOrder_EMC
{
    public class ConvertOpptoOrder_EMC : CodeActivity
    {

        //input parameters
        [RequiredArgument]
        [Input("Opportunity")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> opportunityInput { get; set; }

        //input parameters
        [RequiredArgument]
        [Input("SalesOrder")]
        [ReferenceTarget("salesorder")]
        public InArgument<EntityReference> salesorderInput { get; set; }


        protected override void Execute(CodeActivityContext context)
        {

            ITracingService tracingService = context.GetExtension<ITracingService>();

            tracingService.Trace("Begin:");

            IWorkflowContext iWorkflowContext = context.GetExtension<IWorkflowContext>();

            IOrganizationServiceFactory factory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = factory.CreateOrganizationService(iWorkflowContext.InitiatingUserId);
            tracingService.Trace("Starting Opportunity and Quote References:");
            EntityReference opportunityRef = opportunityInput.Get(context);
            EntityReference salesorderRef = salesorderInput.Get(context);
            tracingService.Trace("Retrieving Opp Products:");
            EntityCollection oppProducts = GetOpportunityProducts(opportunityRef.Id, service);

            tracingService.Trace("Checking to See if Opp Products Exist:");

            if (oppProducts.Entities.Count > 0)
            {
                foreach (Entity e in oppProducts.Entities)
                {
                    tracingService.Trace("Create Quote Detail:");
                    Entity salesorderDetail = new Entity("salesorderdetail");

                    salesorderDetail["salesorderid"] = salesorderRef;
                    salesorderDetail["quantity"] = e["quantity"];
                    salesorderDetail["transactioncurrencyid"] = e["transactioncurrencyid"];
                    salesorderDetail["ispriceoverridden"] = e["ispriceoverridden"];
                    salesorderDetail["productid"] = e["productid"];
                    salesorderDetail["uomid"] = e["uomid"];
                    //hi
                    salesorderDetail["baseamount"] = e["baseamount"];
                    service.Create(salesorderDetail);

                }

            }
            tracingService.Trace("Complete:");
        }

        public EntityCollection GetOpportunityProducts(Guid opportunityId, IOrganizationService service)
        {
            EntityCollection resourceCharacteristics = new EntityCollection();
            QueryExpression qe = new QueryExpression("opportunityproduct");
            qe.Criteria.AddCondition("opportunityid", ConditionOperator.Equal, opportunityId);
            qe.ColumnSet = new ColumnSet("ispriceoverridden", "productid", "uomid", "transactioncurrencyid", "quantity", "baseamount", "extendedamount");
            EntityCollection ec = service.RetrieveMultiple(qe);
            return ec;
        }

    }
}
